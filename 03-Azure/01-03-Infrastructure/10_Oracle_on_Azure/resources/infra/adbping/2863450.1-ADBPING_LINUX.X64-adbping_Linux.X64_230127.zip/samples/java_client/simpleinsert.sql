begin
insert into adbpingtest(id) values(1);
commit;
end;
