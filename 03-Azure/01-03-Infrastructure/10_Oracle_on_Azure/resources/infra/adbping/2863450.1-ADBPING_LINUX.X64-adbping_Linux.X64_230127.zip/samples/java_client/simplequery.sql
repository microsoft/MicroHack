select name, value, inst_id from gv$parameter where name='cpu_count' order by inst_id;
