declare
	l_num NUMBER;
begin
	l_num := 0;
	dbms_session.sleep(3);
end;
