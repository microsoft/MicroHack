create or replace function F_SQUARE(P_NUM NUMBER)
return NUMBER
as
  L_RETURN_VALUE NUMBER;
begin
  L_RETURN_VALUE := P_NUM * P_NUM;
  return L_RETURN_VALUE;
end;
