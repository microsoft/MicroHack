select d_date,d_month,d_year from ssb.dwdate where rownum<10001
