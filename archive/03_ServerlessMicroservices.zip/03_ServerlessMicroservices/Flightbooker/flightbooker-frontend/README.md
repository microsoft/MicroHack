to start run: `npm install`, `npm run dev` or the script from start_frontend.ps1 if you want to start the application with dapr
in the terminal in the flightbooker-frontend folder <br>
If it's not working make sure you have installed all necessary npm resources and have docker desktop running. 
