<script setup></script>

<template>
  <div>
    <h1>MicroAir Booking Service</h1>
    <p>For reservation choose one or more seats.</p>
  </div>
</template>

<style scoped></style>
